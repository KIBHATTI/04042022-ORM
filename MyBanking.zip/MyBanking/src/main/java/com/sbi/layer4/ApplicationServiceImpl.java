package com.sbi.layer4;

import org.springframework.stereotype.Service;

import com.sbi.layer2.Applicant;
import com.sbi.layer3.ApplicantRepository;
import com.sbi.layer3.ApplicantRepositoryImpl;
import com.sbi.layer4.ApplicationService;

@Service
public class ApplicationServiceImpl  implements ApplicationService {

	ApplicantRepository appRepo = new ApplicantRepositoryImpl();
	@Override
	public void createApplicationService(Applicant applicant) {
		appRepo.createApplication(applicant);
		
	}

}