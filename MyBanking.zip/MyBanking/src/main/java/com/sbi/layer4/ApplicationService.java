package com.sbi.layer4;

import org.springframework.stereotype.Service;

import com.sbi.layer2.Applicant;

@Service
public interface ApplicationService
{
	public void createApplicationService(Applicant applicant);
}
