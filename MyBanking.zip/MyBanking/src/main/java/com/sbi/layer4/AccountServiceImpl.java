package com.sbi.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.layer2.Account;
import com.sbi.layer2.Applicant;
import com.sbi.layer2.ApplicationStatus;
import com.sbi.layer3.*;

@Service
public class AccountServiceImpl implements AccountService 
{

	@Autowired
	AccountRepository accRepo;
	
	@Autowired
	ApplicantRepository appRepo;
	@Override
	public Account openBankAccountService(int applicant) {
		
		Applicant applicant1 = appRepo.findApplication(40);
		if(applicant1 != null)
		{
			Account account = new Account();
			account.setAccountHolderName(applicant1.getApplicantName()); //2
			account.setAccoutBalance(5000); //3
			account.setApplicant(applicant1); //4
		
			applicant1.setApplicationStatus(ApplicationStatus.APPROVED);
		
			appRepo.modifyApplication(applicant1);
			accRepo.createAccount(account);
			
		}
		return null;
	}

	
}
