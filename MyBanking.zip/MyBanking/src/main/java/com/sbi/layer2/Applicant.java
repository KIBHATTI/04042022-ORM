package com.sbi.layer2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="applicant_tbl")
public class Applicant 
{
	@Id
	@GeneratedValue
	@Column(name="applicant_id")
	private int applicantId;
	
	@Column(name="account_type")
	private String accountType;
	
	@Column(name="applicant_name")
	private String applicantName;
	
	@Column(name="applicant_mobile")
	private String applicantMobile;
	
	@Column(name="applicant_dob")
	private LocalDate applicantBirthDate;
	
	@Column(name="applicant_father")
	private String applicantFatherName;
	
	@Column(name="applicant_married")
	private String married;
	
	@Column(name="applicant_occupation")
	private String occupation;
	
	@Column(name="applicant_income")
	private String annualIncome;
	
	@OneToMany(mappedBy="applicant" , cascade=CascadeType.ALL)
	List<Address> addressList = new ArrayList<Address>();
	
	@Column(name="applicant_adhaar")
	private String adhdaarNumber;
	
	@Column(name="applicant_pancard")
	private String panCard;
	
	@Column(name="applicant_photo")
	private String photo;
	
	private String applicationStatus; // PENDING IN_PROGRESS APPROVED REJECTED

	
	
	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public String getMarried() {
		return married;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getApplicantMobile() {
		return applicantMobile;
	}

	public void setApplicantMobile(String applicantMobile) {
		this.applicantMobile = applicantMobile;
	}

	public LocalDate getApplicantBirthDate() {
		return applicantBirthDate;
	}

	public void setApplicantBirthDate(LocalDate applicantBirthDate) {
		this.applicantBirthDate = applicantBirthDate;
	}

	public String getApplicantFatherName() {
		return applicantFatherName;
	}

	public void setApplicantFatherName(String applicantFatherName) {
		this.applicantFatherName = applicantFatherName;
	}

	
	public void setMarried(String married) {
		this.married = married;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}

	public String getAdhdaarNumber() {
		return adhdaarNumber;
	}

	public void setAdhdaarNumber(String adhdaarNumber) {
		this.adhdaarNumber = adhdaarNumber;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}
	
	
	
	
}
