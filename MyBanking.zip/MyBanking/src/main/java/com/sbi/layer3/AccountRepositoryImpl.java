package com.sbi.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.layer2.Account;

@Repository
public class AccountRepositoryImpl extends BaseRepositoryImpl implements AccountRepository
{

	public AccountRepositoryImpl()
	{
		System.out.println("in accout repo imp");
		
	}
	
	@Transactional
	public void createAccount(Account account) {
		System.out.println("creatin account in Account RepoImpl");
		super.persist(account);
		System.out.println("after persist");
		
	}

	

	public void modifyAccount(Account account) {
		super.merge(account);
		
	}

	public void removeAccount(int acno) {
		Account accObj = super.find(Account.class, acno);
		super.remove(accObj);
		
	}

	public Account findAccount(int acno) {
		return super.find(Account.class, acno);
		
	}

	public List<Account> findAllAccount() {
		return super.findAll("Account");
	}

}
