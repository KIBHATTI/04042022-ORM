package com.sbi.layer3;

import java.util.List;

import com.sbi.layer2.Applicant;

public interface ApplicantRepository 
{
	void createApplication(Applicant applicant);
	void modifyApplication(Applicant applicant);
	void removeApplication(int applicantId);
	Applicant findApplication(int applicantId);
	List<Applicant> findAllApplicants();
}
