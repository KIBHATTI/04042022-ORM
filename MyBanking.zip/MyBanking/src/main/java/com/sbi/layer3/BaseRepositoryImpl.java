package com.sbi.layer3;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;


@Repository
public class BaseRepositoryImpl implements BaseRepository
{

	//@PersistenceContext(unitName="MyJPA")
	EntityManager entityManager;
	
	public BaseRepositoryImpl()
	{
		System.out.println("in base repo imp");
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("MyJPA");
		entityManager = emf.createEntityManager();
		System.err.println("BASE DAO IMP()....."+entityManager);
	}
	
	
	public void persist(Object obj)		//USER DEFINED FUCNTION
	{
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();
		entityManager.persist(obj);		//ORMS PERSIST
		tx.commit();
	}
	
	
	public void remove(Object obj)
	{
		
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();
		entityManager.remove(obj);
		tx.commit();
	}
	

	public void merge(Object obj)
	{
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();
		entityManager.merge(obj);
		tx.commit();
	}
	
	public <AnyType> AnyType find(Class<AnyType> className,Serializable primaryKey)
	{
		AnyType e =entityManager.find(className,primaryKey);
		return e;
	}
	
	public <AnyType> List<AnyType> findAll(String entityName)
	{
		Query query=entityManager.createQuery("From "+entityName);
		return query.getResultList();
	}
}
