package com.sbi;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.layer2.Address;
import com.sbi.layer2.Applicant;
import com.sbi.layer2.ApplicationStatus;
import com.sbi.layer4.ApplicationService;
import com.sbi.layer4.ApplicationServiceImpl;

/**
 * Servlet implementation class ApplicantServlet
 */

@WebServlet("/applicant")    //STEP 2
public class ApplicantServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	ApplicationService appService = new ApplicationServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApplicantServlet() {
        super();
        ApplicationContext ctx = new ClassPathXmlApplicationContext("myspring.xml");
        System.out.println("in Application Servelt CTX..... "+ctx);
     
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
//	public void init(ServletConfig config) throws ServletException {
//		
//	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	//STEP 3
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		
		String acType=request.getParameter("actype" );
		String acHolderName=request.getParameter( "app_name");
		String acHolderFather=request.getParameter("app_fathername");
		String acHolderDob =request.getParameter("app_dob");
		String acHolderMobile=request.getParameter("app_mobno");
		String acHolderMaritalStatus=request.getParameter("app_maritalstatus");
		String acHolderOccupation=request.getParameter("app_occupation");
		String acHolderAnnualIncome=request.getParameter( "app_annualincome");
		String acHolderAdhar=request.getParameter("app_adhaarno");
		String acHolderPanCard=request.getParameter("app_panno");
		String acHoldePermArea=request.getParameter("app_p_area");
		String acHoldePermStreet=request.getParameter("app_p_street");
		String acHoldePermCity=request.getParameter("app_p_city");
		String acHoldePermState=request.getParameter("app_p_state");
		String acHoldePermCountry=request.getParameter("app_p_country");
		String acHoldePermPin=request.getParameter("app_p_pin");

			  
		String acHolderCorrArea=request.getParameter("app_c_area");
		String acHolderCorrStreet=request.getParameter("app_c_street");
		String acHolderCorrCity=request.getParameter("app_c_city");
		String acHolderCorrState=request.getParameter("app_c_state");
		String acHolderCorrCountry=request.getParameter("app_c_country");
		String acHolderCorrPin=request.getParameter("app_c_pin");
		
		Applicant applicant = new Applicant();
		
		applicant.setAccountType(acType);
		applicant.setApplicantName(acHolderName);
		applicant.setApplicantFatherName(acHolderFather);
		applicant.setApplicantBirthDate(LocalDate.parse(acHolderDob));
		applicant.setApplicantMobile(acHolderMobile);
		applicant.setMarried(acHolderMaritalStatus);
		applicant.setOccupation(acHolderOccupation);
		applicant.setAnnualIncome(acHolderAnnualIncome);
		applicant.setAdhdaarNumber(acHolderAdhar);
		applicant.setPanCard(acHolderPanCard);
	
		
		Address permanentAdd = new Address();
		permanentAdd.setAddressType("Permanent");
		permanentAdd.setAddressType(acHoldePermArea);
		permanentAdd.setArea(acHoldePermArea);
		permanentAdd.setStreet(acHoldePermStreet);
		permanentAdd.setCity(acHoldePermCity);
		permanentAdd.setState(acHoldePermState);
		permanentAdd.setCountry(acHoldePermCountry);
		permanentAdd.setPin(acHoldePermPin);
		permanentAdd.setApplicant(applicant);
		
		Address corAdd = new Address();
		corAdd.setAddressType("Corresspondence");
		corAdd.setArea(acHolderCorrArea);
		corAdd.setStreet(acHolderCorrStreet);
		corAdd.setCity(acHolderCorrCity);
		corAdd.setState(acHolderCorrState);
		corAdd.setCountry(acHolderCorrCountry);
		corAdd.setPin(acHolderCorrPin);
		corAdd.setApplicant(applicant);
		
		List<Address> addrList = new ArrayList<Address>();
		
		addrList.add(permanentAdd);//create a new row in the Address table
		addrList.add(corAdd);
	
		applicant.setAddressList(addrList);
		applicant.setPhoto("452.jpg");
	
		
		applicant.setApplicationStatus(ApplicationStatus.APPLIED);
		
		appService.createApplicationService(applicant);
		
		PrintWriter pw = response.getWriter();
		pw.println("<h2>Thank you"+acHolderName+"</h2>");
		pw.println("<h3> Your account opening application is submitted</h3>");
		pw.println("<a href ='http://192.168.0.106:8080/MyBanking/'>Home</a>");
		System.out.println(acHolderName+"  has submitted the application.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
