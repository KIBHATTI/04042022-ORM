package com.sbi.layer5;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sbi.layer2.Applicant;

@Controller
@RequestMapping("/applicant")
public class ApplicantController
{
	
	public ApplicantController()
	{
		System.out.println(" ApplicantController Constructor ");
	}
	@RequestMapping("/greeting") //CONTROLLER
	public String greeting(){
		System.out.println(" greeeting is called");
		
		//WRITE LOGIC I.E MODEL
		
		
		return "Greeting";  //VIIEW
	}
	@RequestMapping("/apply")
	public String applyForNewBankAccount()
	{
		System.out.println("in apply for new bank account");
		
		return "ApplyForBankAccount";
	}
	
	@RequestMapping("/create")
	public String createApplicantData(Applicant appObj)
	{
		System.out.println("Create Application Data");
		return null;
	}
	
	
}
