package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.ApplicantRepository;
import com.sbi.project.layer3.ApplicantRepositoryImpl;
import com.sbi.project.layer4.ApplicationService;

@Service
public class ApplicationServiceImpl  implements ApplicationService {

	@Autowired
	ApplicantRepository appRepo;
	@Override
	public void createApplicationService(Applicant applicant) {
		appRepo.createApplication(applicant);
		
	}
	@Override
	public List<Applicant> getAllApplicants() {
		
		return appRepo.findAllApplicants();
	}

}