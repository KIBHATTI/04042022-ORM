package com.sbi.project.layer2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="applicant_tbl")
public class Applicant 
{
	@Id
	@GeneratedValue
	@Column(name="applicant_id")//1
	private int applicantId;
	
	@Column(name="account_type")//2
	private String accountType;
	
	@Column(name="applicant_name")//3
	private String applicantName;
	
	@Column(name="applicant_mobile")//4
	private String applicantMobile;
	
	@Column(name="applicant_dob")//5
	private LocalDate applicantBirthDate;
	
	@Column(name="applicant_father")//6
	private String applicantFatherName;
	
	@Column(name="applicant_married")//7
	private String married;
	
	@Column(name="applicant_occupation")//8
	private String occupation;
	
	@Column(name="applicant_income")//9
	private String annualIncome;
	
	@OneToMany(mappedBy="applicant" , cascade=CascadeType.ALL)
	List<Address> addressList = new ArrayList<Address>();
	
	@Column(name="applicant_adhaar")//10
	private String adhdaarNumber;
	
	@Column(name="applicant_pancard")//11
	private String panCard;
	
	@Column(name="applicant_photo")//12
	private String photo;
	
	private String applicationStatus; //13 PENDING IN_PROGRESS APPROVED REJECTED

	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getApplicantMobile() {
		return applicantMobile;
	}

	public void setApplicantMobile(String applicantMobile) {
		this.applicantMobile = applicantMobile;
	}

	public LocalDate getApplicantBirthDate() {
		return applicantBirthDate;
	}

	public void setApplicantBirthDate(LocalDate applicantBirthDate) {
		this.applicantBirthDate = applicantBirthDate;
	}

	public String getApplicantFatherName() {
		return applicantFatherName;
	}

	public void setApplicantFatherName(String applicantFatherName) {
		this.applicantFatherName = applicantFatherName;
	}

	public String getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public List<Address> getAddressList() {
		return addressList;
	}

	public void setAddressList(List<Address> addressList) {
		this.addressList = addressList;
	}

	public String getAdhdaarNumber() {
		return adhdaarNumber;
	}

	public void setAdhdaarNumber(String adhdaarNumber) {
		this.adhdaarNumber = adhdaarNumber;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	
	
		
	
	
}
