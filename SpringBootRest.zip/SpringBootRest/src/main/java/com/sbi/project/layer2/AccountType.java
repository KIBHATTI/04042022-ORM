package com.sbi.project.layer2;

public interface AccountType 
{
	String SAVINGS="Savings";
	String CURRENT="Current";
	String RECURRING="Recurring";
	String FIXEDDEPOSIT="FixedDeposit";
}
