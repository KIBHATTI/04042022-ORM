package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.management.RuntimeErrorException;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emps")
public class EmployeeController 
{
	ArrayList<Employee> staff = new ArrayList<Employee>();
	
	public EmployeeController()
	{
		System.out.println("In Employee Controller");
		Employee employee = new Employee(1245,"Michael","Manager",LocalDate.of(2010, 10, 25),41000,35);
		Employee employee1 = new Employee(1270,"Lincoln","Salesman",LocalDate.of(2017, 1, 15),45000,35);
		Employee employee2 = new Employee(1218,"Ross","President",LocalDate.of(2018, 11, 1),65000,26);
		Employee employee3 = new Employee(1236,"Monica","Manager",LocalDate.of(2016, 7, 10),50000,28);
		staff.add(employee); staff.add(employee1); staff.add(employee2); staff.add(employee3);
	}
	
	@RequestMapping("/getEmp")
	public Employee getEmployeeObject()
	{
		Employee employee = new Employee();
		employee.setEmpNumber(36985);
		employee.setName("Jonnathna");
		employee.setAge(32);
		employee.setSalary(47000);
		employee.setJoiningDate(LocalDate.of(2019, 12, 12));
		employee.setJob("CLERK");
		return employee;
	}
	@RequestMapping("/")
	public List<Employee> getAllEmployees()
	{
		System.out.println("Return all EMps");
		return staff;
		
	}
	
	@RequestMapping("/{eno}")
	public Employee getEmpBasedOnEmpNo(@PathVariable("eno") int employeeNumberToSearch) 
	{
		System.out.println("/{eno}");
		boolean employeeFound=false;
		Employee employeeObj=null;
		for(int i=0;i<staff.size();i++)
		{
			employeeObj=staff.get(i);
			if(employeeObj.getEmpNumber() == employeeNumberToSearch)
			{
				employeeFound=true;
				break;
			}
		}
		if(employeeFound==true)
		{
			return employeeObj;
		}else
		{
			throw new RuntimeException();
			
		}
	}
	
	@RequestMapping("/DeleteEmp/{eno}")
	public String getDeleteEmpBasedOnEmpNo(@PathVariable("eno") int employeeNumberToSearch) 
	{
		System.out.println("/{eno}");
		boolean employeeFound=false;
		Employee employeeObj=null;
		for(int i=0;i<staff.size();i++)
		{
			employeeObj=staff.get(i);
			if(employeeObj.getEmpNumber() == employeeNumberToSearch)
			{
				employeeFound=true;
				staff.remove(i);
				break;
			}
		}
		if(employeeFound==true)
		{
			return "Employee"+employeeNumberToSearch+" Deleted";
		}else return "Employee does not Exist";
	}
	
	@RequestMapping("/UpdateEmp")
	public String getUpdateEmpBasedOnEmpNo(@RequestBody Employee employeeObjectToModify) 
	{
		System.out.println("update emp /{eno}");
		boolean employeeFound=false;
		Employee employeeObj=null;
		for(int i=0;i<staff.size();i++)
		{
			employeeObj=staff.get(i);
			if(employeeObj.getEmpNumber() == employeeObjectToModify.getEmpNumber())
			{
				employeeFound=true;
				staff.remove(i);
				staff.add(employeeObjectToModify);
				break;
			}
		}
		if(employeeFound==true)
		{
			return "Employee"+employeeObjectToModify+" added";
		}else return "Employee does not Exist";
	}
	
	@RequestMapping("/addEmp")
	public String getAddEmp(@RequestBody Employee employeeObjectToAdd) 
	{
		System.out.println("Add emp /{eno}");
		boolean employeeFound=false;
		Employee employeeObj=null;
		for(int i=0;i<staff.size();i++)
		{
			employeeObj=staff.get(i);
			if(employeeObj.getEmpNumber() == employeeObjectToAdd.getEmpNumber())
			{
				employeeFound=true;
				break;
			}
		}
		if(employeeFound==true)
		
			return "Employee already exists";
		else
			{
				staff.add(employeeObjectToAdd);
				return "Employee Object added successfully";
			}
	}
}
