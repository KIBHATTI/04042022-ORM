package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.*;

@RestController
@RequestMapping("/applicant")
public class ApplicantController
{
	@Autowired
	ApplicationService applicantService;
	
	public ApplicantController()
	{
		System.out.println(" ApplicantController Constructor ");
	}
	@RequestMapping("/getApplicants")
	public List<Applicant> getAllApplicants()
	{
		System.out.println("/getApplicants");
		return applicantService.getAllApplicants();
	}
	
}
