package com.sbi.project.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="account_tbl")
public class Account 
{
	@Id
	@GeneratedValue
	@Column(name="account_no")
	private int accountNumner;
	
	@Column(name="acc_name")
	private String accountHolderName;
	
	@Column(name="acc_bal")
	private float accoutBalance;
	
	@OneToOne
	@JoinColumn(name="app_id")
	Applicant applicant;
		

	public Applicant getApplicant() {
		return applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

	public int getAccountNumner() {
		return accountNumner;
	}

	public void setAccountNumner(int accountNumner) {
		this.accountNumner = accountNumner;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public float getAccoutBalance() {
		return accoutBalance;
	}

	public void setAccoutBalance(float accoutBalance) {
		System.out.println("Setting balance");
		this.accoutBalance = accoutBalance;
	}
	
	
	
	
}
