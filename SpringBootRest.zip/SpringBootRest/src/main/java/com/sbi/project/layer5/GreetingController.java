package com.sbi.project.layer5;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


//http://localhost:8080/greetings/greet

@RestController
@RequestMapping("/greetings")
public class GreetingController 
{
	@RequestMapping("/greet")
	
	public String greetingMessage()
	{
		return "<h2>Welcome to Spring rest Based App</h2>";
	}
	@RequestMapping("/boot")
	public String welcomeMessage()
	{
		return "Booting ";
	}
	@RequestMapping("/web")
	public String regarsdMessage()
	{
		return "Web app messgae ";
	}
	
	//@RequestMapping("/employeedetails")
//	public Employee employeeDetails()
//	{
//		System.out.println("in print before");
//		Employee e = new Employee("1236","Kanwar","Trainee Officer");
//		System.out.println("in print after"+e.toString());
//		//return e.toString();
//		return e;
//		
//	}
}
